# KREEZ CASHIER — Windows 7 package

This folder contains the Windows desktop edition under `windows/` and the GitHub Actions workflow under `.github/workflows/`.

The desktop build uses Electron 22.3.27 and targets Windows x86 (32-bit). The cashier UI runs offline; the invoice QR image is embedded in the HTML and points to the KREEZ Links page. Reports show manually entered cash capital plus inventory value at cost and retail price.

To build, upload the `windows/` folder and `.github/workflows/build-windows7.yml` into the existing repository, then run the workflow named **Build KREEZ CASHIER for Windows 7** in GitHub Actions.

Important: the app's local database is separate from Chrome/Android storage. Use the cashier's Backup page to export a JSON backup and restore it in the Windows app before entering live sales.
