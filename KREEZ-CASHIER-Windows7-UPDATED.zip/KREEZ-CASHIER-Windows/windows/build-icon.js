const sharp = require('sharp');
const path = require('path');
const input = path.join(__dirname, 'assets', 'cherry.svg');
const output = path.join(__dirname, 'assets', 'cherry.png');
sharp(input).resize(512, 512).png().toFile(output).then(() => {
  console.log('Cherry icon generated:', output);
}).catch(err => { console.error(err); process.exit(1); });
